# Multislider
A responsive, jQuery powered, multi-slideshow.

View docs at [http://www.multislider.info](http://www.multislider.info)
